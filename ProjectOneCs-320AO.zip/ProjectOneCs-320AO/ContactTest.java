package Tests;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import Contact.Contact;

class ContactTest{

	@DisplayName("Test a valid Constructor")
	@Test
	public void testValidConstructor() {
        String contactId = "1";
      	String firstName = "Andrew";
        String lastName = "Obrochta";
        String phoneNumber = "5209999999";
        String address = "520 Mountain Street";
		
        Contact testContact = new Contact(contactId, firstName, lastName, phoneNumber, address);
        
		assertEquals(1, testContact.getContactID());
		assertEquals(firstName, testContact.getFirstName());
		assertEquals(lastName, testContact.getLastName());
		assertEquals(phoneNumber, testContact.getPhoneNumber());
		assertEquals(address, testContact.getAddress());
	}
	
	@DisplayName("Test invalid Constructor")
	@Test
	public void testinvalidConstructor() {
        String contactId = "2";
      	String firstName = "Andrew";
        String lastName = "Obrochta";
        String phoneNumber = "1111";
        String address = "520 Mountain Street";       
        
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	new Contact(contactId, firstName, lastName, phoneNumber, address);
        });
	}
	@DisplayName("Test Good Firstname")
	@Test
	public void testGoodSetFirst() {
        String contactId = "3";
    	String firstName = "Andrew";
        String lastName = "Obrochta";
        String phoneNumber = "5209999999";
        String address = "520 Mountain Street";
		
        Contact testContact = new Contact(contactId, firstName, lastName, phoneNumber, address);   
        testContact.setFirstName("Test");        
        assertEquals("Test", testContact.getFirstName());
	}
	
	@DisplayName("Test Bad Firstname")
	@Test
	public void testBadSetFirst() {
		  String contactId = "3";
	      String firstName = "Andrew";
	      String lastName = "Obrochta";
	      String phoneNumber = "5209999999";
	      String address = "520 Mountain Street";
		
        Contact testContact = new Contact(contactId, firstName, lastName, phoneNumber, address);   
        
        
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	testContact.setFirstName(null);
        });
	}
	@DisplayName("Test Long Firstname")
	@Test
	
	public void testLongSetFirst() {
		  String contactId = "3";
	      String firstName = "Andrew";
	      String lastName = "Obrochta";
	      String phoneNumber = "5209999999";
	      String address = "520 Mountain Street";
		
        Contact testContact = new Contact(contactId, firstName, lastName, phoneNumber, address);   
        
        
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	testContact.setFirstName("Andrewwwwwwwwwwwww");
        });
	}
	
	@DisplayName("Test Good GetID")
	@Test
	public void testGetID() {
		  String contactId = "3";
	      String firstName = "Andrew";
	      String lastName = "Obrochta";
	      String phoneNumber = "5209999999";
	      String address = "520 Mountain Street";
		
        Contact testContact = new Contact(contactId, firstName, lastName, phoneNumber, address);   
        assertEquals(3, testContact.getContactID());
	}
	
	@DisplayName("Test Bad GetID")
	@Test
	public void testBadGetID() {
		  String contactId = "3";
	      String firstName = "Andrew";
	      String lastName = "Obrochta";
	      String phoneNumber = "5209999999";
	      String address = "520 Mountain Street";
		
        Contact testContact = new Contact(contactId, firstName, lastName, phoneNumber, address);   
        assertNotEquals("3", testContact.getContactID());
	}
	
	@DisplayName("Test Long GetID")
	@Test
	public void testlongGetID() {
        String contactId = "9999999999999";
        String firstName = "Andrew";
	    String lastName = "Obrochta";
	    String phoneNumber = "5209999999";
	    String address = "520 Mountain Street";
		
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	new Contact(contactId, firstName, lastName, phoneNumber, address);
        });
	}
	@DisplayName("Test Bad lastname")
	@Test
	public void testBadSetLast() {
        String contactId = "3";
        String firstName = "Andrew";
	    String lastName = "Obrochta";
	    String phoneNumber = "5209999999";
	    String address = "520 Mountain Street";
		
        Contact testContact = new Contact(contactId, firstName, lastName, phoneNumber, address);   
        
        
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	testContact.setLastName(null);
        });
	}
	
	@DisplayName("Test an invalid length LastName")
	@Test
	public void testLongSetLast() {
        String contactId = "3";
        String firstName = "Andrew";
	    String lastName = "Obrochta";
	    String phoneNumber = "5209999999";
	    String address = "520 Mountain Street";
		
        Contact testContact = new Contact(contactId, firstName, lastName, phoneNumber, address);   
        
        
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	testContact.setLastName("Obrochtaaaaaaaaaaaaaaaaa");
        });
	}
	
	@DisplayName("Test a valid LastName")
	@Test
	public void testGoodsetLast() {
		 String contactId = "3";
	        String firstName = "Andrew";
		    String lastName = "Obrochta";
		    String phoneNumber = "5209999999";
		    String address = "520 Mountain Street";
		
        Contact testContact = new Contact(contactId, firstName, lastName, phoneNumber, address);   
        testContact.setLastName("Obrochta");        
        assertEquals("Obrochta", testContact.getLastName());
	}
	
	@DisplayName("Test a Null phonenumber")
	@Test
	public void testBadSetPhone() {
		String contactId = "3";
        String firstName = "Andrew";
	    String lastName = "Obrochta";
	    String phoneNumber = "5209999999";
	    String address = "520 Mountain Street";
		
        Contact testContact = new Contact(contactId, firstName, lastName, phoneNumber, address);   
        
        
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	testContact.setPhoneNumber(null);
        });
        
	}
	
	@DisplayName("Test an invalid length PhoneNumber")
	@Test
	public void testWrongLengthPhone() {
		String contactId = "3";
        String firstName = "Andrew";
	    String lastName = "Obrochta";
	    String phoneNumber = "5209999999";
	    String address = "520 Mountain Street";
		
        Contact testContact = new Contact(contactId, firstName, lastName, phoneNumber, address);   
        
        
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	testContact.setPhoneNumber("1");
        });
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	testContact.setPhoneNumber("9999999999999999");
        });
	}
	@DisplayName("Test a valid length setPhoneNumber")
	@Test
	public void testGoodPhone() {
		String contactId = "3";
        String firstName = "Andrew";
	    String lastName = "Obrochta";
	    String phoneNumber = "5209999999";
	    String address = "520 Mountain Street";
		
        Contact testContact = new Contact(contactId, firstName, lastName, phoneNumber, address);   

        testContact.setPhoneNumber("5209999999");        
        assertEquals("5209999999", testContact.getPhoneNumber());

	}
	
	@DisplayName("Test an invalid null setAddress")
	@Test
	public void testNullSetAddress() {
		String contactId = "3";
        String firstName = "Andrew";
	    String lastName = "Obrochta";
	    String phoneNumber = "5209999999";
	    String address = "520 Mountain Street";
		
        Contact testContact = new Contact(contactId, firstName, lastName, phoneNumber, address);   
        
        
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	testContact.setAddress(null);
        });
        
	}
	
	@DisplayName("Test an wrong length address")
	@Test
	public void testWrongLengthAddress() {
		String contactId = "3";
        String firstName = "Andrew";
	    String lastName = "Obrochta";
	    String phoneNumber = "5209999999";
	    String address = "520 Mountain Street";
		
        Contact testContact = new Contact(contactId, firstName, lastName, phoneNumber, address);   
        
        
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	testContact.setAddress("9999999999999999999999999 mountain arizona avenue st");
        });
	}
	
	@DisplayName("Test a valid length setAddress")
	@Test
	public void testGoodAddress() {
		String contactId = "3";
        String firstName = "Andrew";
	    String lastName = "Obrochta";
	    String phoneNumber = "5209999999";
	    String address = "520 Mountain Street";
		
        Contact testContact = new Contact(contactId, firstName, lastName, phoneNumber, address);   

        testContact.setAddress("520 Mountain Street");        
        assertEquals("520 Mountain Street", testContact.getAddress());

	}
	
}
