package Tests;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import Contact.ContactService;

class ContactServiceTest {
	
	
	@AfterEach
	void tearDown() throws Exception {
		ContactService.contactList.clear();
	}


	@DisplayName("Test Add Contact")
	@Test
	void testAddContact() {

		String firstName = "Andrew";
		String lastName = "Obrochta";
		String phoneNumber = "5209999999";
		String address = "520 Mountain Street";

		ContactService test = new ContactService();

		assertTrue(ContactService.contactList.isEmpty());

		test.addContact(firstName, lastName, phoneNumber, address);

		assertFalse(ContactService.contactList.isEmpty());
		assertEquals(0, ContactService.contactList.get(0).getContactID());
		assertEquals(firstName, ContactService.contactList.get(0).getFirstName());
		assertEquals(lastName, ContactService.contactList.get(0).getLastName());
		assertEquals(phoneNumber, ContactService.contactList.get(0).getPhoneNumber());
		assertEquals(address, ContactService.contactList.get(0).getAddress());

	}

	@DisplayName("Test Delete Contact")			  
	@Test void testDeleteContact() {
				  
		String firstName = "Andrew"; 
		String lastName = "Obrochta"; 
		String phoneNumber = "5209999999"; 
		String address = "520 Mountain Street";
		boolean testBool = false;
		  
		ContactService test = new ContactService();
		  
		assertTrue(ContactService.contactList.isEmpty());
		 
		test.addContact(firstName, lastName, phoneNumber, address);//object at ID 0
		test.addContact(firstName, lastName, phoneNumber, address);//object at ID 1
		test.addContact(firstName, lastName, phoneNumber, address);//object at ID 2
		  
		assertEquals(3,ContactService.contactList.size());
		  
		test.deleteContact("1");
		  
		assertEquals(2,ContactService.contactList.size());
		 
		
		for(int i = 0; i < ContactService.contactList.size(); i++) {
			if(ContactService.contactList.get(i).getContactID() == 1) {
				testBool = true;
			}
		}		
		assertFalse(testBool);				 
	}

	@DisplayName("Test Edit phone number")
	@Test
	void testEditPhone() {
		
		String firstName = "Andrew"; 
		String lastName = "Obrochta"; 
		String phoneNumber = "5209999999"; 
		String address = "520 Mountain Street";
		  
		ContactService test = new ContactService();
		test.addContact(firstName, lastName, phoneNumber, address);
		
		assertEquals(phoneNumber, ContactService.contactList.get(0).getPhoneNumber());
		
		test.editNumber("0", "5209999999");
		assertEquals("5209999999", ContactService.contactList.get(0).getPhoneNumber());
	}

	@DisplayName("Test editing a last name")
	@Test
	void testEditLast() {
		
		String firstName = "Andrew"; 
		String lastName = "Obrochta"; 
		String phoneNumber = "5209999999"; 
		String address = "520 Mountain Street";
		  
		ContactService test = new ContactService();
		test.addContact(firstName, lastName, phoneNumber, address);
		
		assertEquals(lastName, ContactService.contactList.get(0).getLastName());
		
		test.editLastName("0", "Smith");
		assertEquals("Smith", ContactService.contactList.get(0).getLastName());
	}

	@DisplayName("Test edit first name")
	@Test
	void testEditFirst() {
		
		String firstName = "Andrew"; 
		String lastName = "Obrochta"; 
		String phoneNumber = "5209999999"; 
		String address = "520 Mountain Street";

		ContactService test = new ContactService();
		test.addContact(firstName, lastName, phoneNumber, address);
		
		assertEquals(firstName, ContactService.contactList.get(0).getFirstName());
		
		test.editFirstName("0", "Steve");
		assertEquals("Steve", ContactService.contactList.get(0).getFirstName());
	}

	@DisplayName("Test edit address")
	@Test
	void testEditAddress() {
		
		String firstName = "Andrew"; 
		String lastName = "Obrochta"; 
		String phoneNumber = "5209999999"; 
		String address = "520 Mountain Street";

		ContactService test = new ContactService();
		test.addContact(firstName, lastName, phoneNumber, address);
		
		assertEquals(address, ContactService.contactList.get(0).getAddress());
		
		test.editAddress("0", "520 North Street");
		assertEquals("520 North Street", ContactService.contactList.get(0).getAddress());
	}
}

