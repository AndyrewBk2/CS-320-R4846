package Appointment;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class ApptServiceTests {

	@AfterEach
	void tearDown() throws Exception {
		AppointmentService.appointments.clear();
	}

	@DisplayName("Adding an Appointment")
	@Test
	void testAddUniqueAppt() {
		String id = "0";
		String description = "This is a good description";
		Calendar c = Calendar.getInstance();

		c.set(Calendar.MONTH, 04);
		c.set(Calendar.DATE, 07);
		c.set(Calendar.YEAR, 2024);

		Date goodDate = c.getTime();

		AppointmentService tempAppt = new AppointmentService();

		assertEquals(0, AppointmentService.appointments.size());

		tempAppt.addUniqueAppointment(goodDate, description);

		assertTrue(AppointmentService.appointments.containsKey(id));
		assertEquals(goodDate, AppointmentService.appointments.get(id).getDate());
		assertEquals(description, AppointmentService.appointments.get(id).getDescription());
	}
	
	@DisplayName("Adding an Appointment with empty description")
	@Test
	void testAddEmptyDesc() {
		String description = ""; // Invalid description
		Calendar c = Calendar.getInstance();

		c.set(Calendar.MONTH, 04);
		c.set(Calendar.DATE, 07);
		c.set(Calendar.YEAR, 2024);

		Date goodDate = c.getTime();

      	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
      		AppointmentService tempAppt = new AppointmentService();
      		tempAppt.addUniqueAppointment(goodDate, description);
        });
      	
      	assertEquals("Invalid description", exception.getMessage());

	}
	
	@DisplayName("Adding an Appointment with null description")
	@Test
	void testAddNullDesc() {
		String description = null; // Invalid description
		Calendar c = Calendar.getInstance();

		c.set(Calendar.MONTH, 04);
		c.set(Calendar.DATE, 07);
		c.set(Calendar.YEAR, 2024);

		Date goodDate = c.getTime();

      	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
      		AppointmentService tempAppt = new AppointmentService();
      		tempAppt.addUniqueAppointment(goodDate, description);
        });
      	
      	assertEquals("Invalid description", exception.getMessage());
	}

	@DisplayName("Deleting an Appointment")
	@Test
	void testDeleteAppt() {

		String description = "This is a good description";
		Calendar c = Calendar.getInstance();

		c.set(Calendar.MONTH, 04);
		c.set(Calendar.DATE, 07);
		c.set(Calendar.YEAR, 2024);

		Date goodDate = c.getTime();

		AppointmentService tempAppt = new AppointmentService();

		assertEquals(0, AppointmentService.appointments.size());

		tempAppt.addUniqueAppointment(goodDate, description);
		tempAppt.addUniqueAppointment(goodDate, description);
		tempAppt.addUniqueAppointment(goodDate, description);

		assertEquals(3, AppointmentService.appointments.size());

		tempAppt.deleteAppointment("1");

		assertEquals(2, AppointmentService.appointments.size());
		assertFalse(AppointmentService.appointments.containsKey("1"));
		
		tempAppt.deleteAppointment("1");
		assertEquals(2, AppointmentService.appointments.size());
	}
}